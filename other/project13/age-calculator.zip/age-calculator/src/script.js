// get DOM elements
const form = document.querySelector('form'); // Select the <form> element in the DOM
const birthdateInput = document.querySelector('#birthdate'); // Select the element with the ID 'birthdate'
const ageOutput = document.querySelector('#age'); // Select the element with the ID 'age'

// listen for form submit event
form.addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent the form from submitting and refreshing the page

  // get input value
  const birthdateString = birthdateInput.value; // Retrieve the value entered in the birthdate input field

  // validate input with regex
  const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/; // Define a regular expression to match the format MM/DD/YYYY
  if (!dateRegex.test(birthdateString)) {
    // If the input does not match the regex pattern
    alert('Please enter a valid birthdate in MM/DD/YYYY format.'); // Show an alert message
    return; // Stop executing the rest of the code
  }

  // parse input as date object
  const birthdate = new Date(birthdateString); // Convert the validated birthdate string into a Date object

  // calculate age
  const ageInMilliseconds = Date.now() - birthdate.getTime(); // Calculate the difference between the current date and the birthdate in milliseconds
  const ageDate = new Date(ageInMilliseconds); // Create a new Date object based on the age difference in milliseconds
  const age = Math.abs(ageDate.getUTCFullYear() - 1970); // Calculate the age by subtracting the birth year from the current year

  // display age
  ageOutput.textContent = `You are ${age} years old.`; // Update the content of the element with the ID 'age' to display the calculated age
});

// listen for form reset event
form.addEventListener('reset', function() {
  ageOutput.textContent = null; // Reset the content of the element with the ID 'age' to null when the form is reset
});
