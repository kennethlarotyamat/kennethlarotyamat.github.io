
// Define the data to be used for the chart. Each object in the array represents a country and its population (in millions).
const data = [
  { country: 'United States', population: 332 },
  { country: 'China', population: 1444 },
  { country: 'India', population: 1392 },
  { country: 'Indonesia', population: 276 },
  { country: 'Pakistan', population: 225 },
  { country: 'Brazil', population: 213 },
  { country: 'Nigeria', population: 211 },
  { country: 'Bangladesh', population: 166 },
  { country: 'Russia', population: 146 },
  { country: 'Mexico', population: 130 }
]

// Define variables for the chart dimensions and scales. The margin object contains the sizes of the margins around the chart. The width and height of the chart are then calculated by subtracting the margins from the total width and height.
const margin = { top: 20, right: 20, bottom: 60, left: 60 }
const width = 800 - margin.left - margin.right
const height = 500 - margin.top - margin.bottom

// Create a band scale for the x-axis. Band scales are useful for data that is categorical (like country names). The domain of the x-scale is set to the country names from the data, and the range is set to the width of the chart. Padding is added to create some space between the bars of the chart.
const x = d3.scaleBand()
  .domain(data.map(d => d.country))
  .range([0, width])
  .padding(0.2)

// Create a linear scale for the y-axis. Linear scales are useful for numerical, continuous data. The domain of the y-scale is set to the range of population numbers in the data (from 0 to the maximum population), and the range is set to the height of the chart. Note that the order of the range is reversed because SVG's y-coordinates start from the top and increase downwards.
const y = d3.scaleLinear()
  .domain([0, d3.max(data, d => d.population)])
  .range([height, 0])

// Create an SVG element for the chart, define its width and height, and append a group element to it. The group element is translated by the left and top margins. This group element will contain all the bars and axes of the chart.
const svg = d3.select('#chart')
  .append('svg')
  .attr('width', width + margin.left + margin.right)
  .attr('height', height + margin.top + margin.bottom + 20)
  .append('g')
  .attr('transform', `translate(${margin.left},${margin.top})`)

// Create rectangles for each data point in the data. Each rectangle represents a bar of the chart. The 'x', 'width', 'y', and 'height' attributes of each rectangle are set using the x and y scales and the data. The 'fill' attribute sets the color of the bars. Interactivity is added with mouseover and mouseout events that change the color of the bar when the mouse is over it.
svg.selectAll('.bar')
  .data(data)
  .enter()
  .append('rect')
  .attr('class', 'bar')
  .attr('x', d => x(d.country)) // The x-position of each bar is determined by the x-scale
  .attr('width', x.bandwidth()) // The width of each bar is determined by the bandwidth of the x-scale
  .attr('y', d => y(d.population)) // The y-position of each bar is determined by the y-scale
  .attr('height', d => height - y(d.population)) // The height of each bar is determined by the chart height and the y-scale
  .attr('fill', 'steelblue') // Set the color of the bars
  .on("mouseover", function (d) { // Add interactivity: When the mouse is over a bar, change its color to light blue
    d3.select(this).style("fill", "#5db0f5")
  })
  .on("mouseout", function (d) { // Add interactivity: When the mouse is moved out of a bar, change its color back to steel blue
    d3.select(this).style("fill", "steelblue")
  })

// Add x-axis labels to the chart. An x-axis generator is created with d3.axisBottom(x) and called on a new group element. The group element is translated down by the height of the chart. The text labels of the x-axis are then styled and rotated to fit better.
svg.append('g')
  .attr('transform', `translate(0,${height})`)
  .call(d3.axisBottom(x)) // Create an x-axis generator and call it on a new group element
  .selectAll('text')
  .style('text-anchor', 'end') // Align the text labels to the end, so they align better when rotated
  .attr('dx', '-.8em') // Move the text labels slightly to the left
  .attr('dy', '.15em') // Move the text labels slightly down
  .attr('transform', 'rotate(-65)') // Rotate the text labels by -65 degrees

// Add y-axis labels to the chart. A y-axis generator is created with d3.axisLeft(y) and called on a new group element.
svg.append('g')
  .call(d3.axisLeft(y)) // Create a y-axis generator and call it on a new group element
