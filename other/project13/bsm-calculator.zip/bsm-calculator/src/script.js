/* The Black and Scholes (1973) Stock option formula */
/*
S=Stock price
X=Strike price
T=Years to maturity
r= Risk-free rate
v=Volatility
*/
export const optionBSM = {
  // Inputs
  // stock: 100, // Stock
  // strike: 100, // Strike
  // time: 90 / 365, // Time to expiration (annualised / 365 days)
  // rate: 0.0025, // Risk-free interest rate
  // vol: 0.2, // Implied volatility
  stock: 0, // Stock
  strike: 0, // Strike
  time: 0, // Time to expiration (annualised / 365 days)
  rate: 0, // Risk-free interest rate
  vol: 0, // Implied volatility

  // Outputs
  callPrice: 0,
  callInt: 0,
  callExt: 0,
  callDelta: 0,
  callTheta: 0,
  putPrice: 0,
  putInt: 0,
  putExt: 0,
  putDelta: 0,
  putTheta: 0,
  gamma: 0,
  vega: 0,

  // PUBLIC Methods
  calculate: function () {
    function CND(x) {
      var k = 0;
      var a1 = 0.31938153;
      var a2 = -0.356563782;
      var a3 = 1.781477937;
      var a4 = -1.821255978;
      var a5 = 1.330274429;
      if (x < 0.0) {
        return 1 - CND(-x);
      } else {
        k = 1.0 / (1.0 + 0.2316419 * x);
      }
      return (
        1.0 -
        (Math.exp((-x * x) / 2.0) / Math.sqrt(2 * Math.PI)) *
          k *
          (a1 +
            k *
              (-0.356563782 +
                k * (1.781477937 + k * (-1.821255978 + k * 1.330274429))))
      );
    }
    // Local Variables
    var S = this.stock;
    var X = this.strike;
    var r = this.rate;
    var v = this.vol;
    var T = this.time;
    // Prevent errors when using T = 0
    if (T === 0) {
      T = 0.00000001;
      var d1 = (Math.log(S / X) + (r + (v * v) / 2.0) * T) / (v * Math.sqrt(T));
      var d2 = d1 - v * Math.sqrt(T);

      this.callInt = Math.max(0, S - X);
      this.callExt = 0;
      this.callPrice = this.callInt;

      this.putInt = Math.max(0, X - S);
      this.putExt = 0;
      this.putPrice = this.putInt;
    } else {
      var d1 = (Math.log(S / X) + (r + (v * v) / 2.0) * T) / (v * Math.sqrt(T));
      var d2 = d1 - v * Math.sqrt(T);

      this.callPrice = S * CND(d1) - X * Math.exp(-r * T) * CND(d2);
      this.callInt = Math.max(0, S - X);
      this.callExt = this.callPrice - this.callInt;

      this.putPrice = X * Math.exp(-r * T) * CND(-d2) - S * CND(-d1);
      this.putInt = Math.max(0, X - S);
      this.putExt = this.putPrice - this.putInt;
    }
    this.callDelta = CND(d1);
    this.callTheta =
      (-(S * (Math.exp(-Math.pow(d1, 2) / 2) / Math.sqrt(2 * Math.PI)) * v) /
        (2 * Math.sqrt(T)) -
        r * X * Math.exp(-(r * T)) * CND(d2)) /
      365;
    this.putDelta = CND(d1) - 1;
    this.putTheta =
      (-(S * (Math.exp(-Math.pow(d1, 2) / 2) / Math.sqrt(2 * Math.PI)) * v) /
        (2 * Math.sqrt(T)) +
        r * X * Math.exp(-(r * T)) * CND(-d2)) /
      365;
    this.gamma =
      Math.exp(-Math.pow(d1, 2) / 2) /
      Math.sqrt(2 * Math.PI) /
      (S * v * Math.sqrt(T));
    this.vega =
      (S *
        Math.sqrt(T) *
        (Math.exp(-Math.pow(d1, 2) / 2) / Math.sqrt(2 * Math.PI))) /
      100;
  },
};

// Wrapper function return option premium based on volatility and put/call flag
function getPremium(pcFlag, vol) {
  optionBSM.vol = vol;
  optionBSM.calculate();
  if (pcFlag === 'call') {
    return optionBSM.callPrice;
  } else {
    return optionBSM.putPrice;
  }
}

// Calculate the IV based on call/put option price using bisection method
export function calculateIV(pcFlag, premium) {
  var tempVol = optionBSM.vol;
  var epsilon = 0.00000001;
  var counter = 0;
  var vLow = 0.005; // 0.5 %
  var vHigh = 4; // 400 %
  var cLow = getPremium(pcFlag, vLow);
  var cHigh = getPremium(pcFlag, vHigh);
  var vi = vLow + ((premium - cLow) * (vHigh - vLow)) / (cHigh - cLow);

  while (Math.abs(premium - getPremium(pcFlag, vi)) > epsilon) {
    if (counter++ > 100) {
      optionBSM.vol = tempVol;
      return 'NA';
    }
    if (getPremium(pcFlag, vi) < premium) {
      vLow = vi;
    } else {
      vHigh = vi;
    }
    cLow = getPremium(pcFlag, vLow);
    cHigh = getPremium(pcFlag, vHigh);
    vi = vLow + ((premium - cLow) * (vHigh - vLow)) / (cHigh - cLow);
  }
  optionBSM.vol = tempVol;
  return vi;
}

// Round "value"" to nearest "factor" multiple
function mRound(value, factor) {
  return Math.round(value / factor) * factor;
}

function dRound(value, decimal) {
  var x = Math.pow(10, decimal);
  return (Math.round(value * x) / x).toFixed(decimal);
}


window.onload = () => {
  const input = ['dte', 'strike', 'stock', 'interest', 'volatility'];
  input.forEach((id) =>
    document.getElementById(id).addEventListener('change', updatePage)
  );
  updatePage();
};

function updatePage() {
  optionBSM.time = document.getElementById('dte').value / 365;
  optionBSM.strike = document.getElementById('strike').value;
  optionBSM.stock = document.getElementById('stock').value;
  optionBSM.rate = document.getElementById('interest').value / 100;
  optionBSM.vol = document.getElementById('volatility').value / 100;

  optionBSM.calculate();

  // Show Premiums
  document.getElementById('call-premium').innerHTML =
    '$ ' + optionBSM.callPrice.toFixed(2);
  document.getElementById('call-intrinsic').innerHTML =
    '$ ' + optionBSM.callInt.toFixed(2);
  document.getElementById('call-extrinsic').innerHTML =
    '$ ' + optionBSM.callExt.toFixed(2);
  document.getElementById('put-premium').innerHTML =
    '$ ' + optionBSM.putPrice.toFixed(2);
  document.getElementById('put-intrinsic').innerHTML =
    '$ ' + optionBSM.putInt.toFixed(2);
  document.getElementById('put-extrinsic').innerHTML =
    '$ ' + optionBSM.callExt.toFixed(2);

  // Show Greeks
  document.getElementById('call-delta').innerHTML =
    optionBSM.callDelta.toFixed(4);
  document.getElementById('call-theta').innerHTML =
    optionBSM.callTheta.toFixed(4);
  document.getElementById('put-delta').innerHTML =
    optionBSM.putDelta.toFixed(4);
  document.getElementById('put-theta').innerHTML =
    optionBSM.putTheta.toFixed(4);
  document.getElementById('gamma').innerHTML = optionBSM.gamma.toFixed(4);
  document.getElementById('vega').innerHTML = optionBSM.vega.toFixed(4);
}
