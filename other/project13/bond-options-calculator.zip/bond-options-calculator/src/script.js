function compound( input, interest, length, name, addition ) {
	var accumulated = input
	for ( i=0; i < length; i++ ) {
		accumulated *= interest
		if ( addition ){
			accumulated += input
		}
	}
  $("p.isaresult1 span").text(parseFloat(accumulated).toFixed(2));
}

var amount = '';
var bond = '';
var term = '';
$(".update, .update2").on("change paste keyup", function() {
  
      amount = $('#investment').val().replace(/\u00A3|\,/g, "");
      bond = $('#bondoptions').val();
      
      goldpayment1 = (amount / 100 *9) / 2;
      goldpayment2 = ((parseInt(amount) / 100 *9) * 2) + parseInt(amount);
      proppayment1 = (amount / 100 *8.5);
      proppayment2 = ((parseInt(amount) / 100 *8.5) * 5) + parseInt(amount);
      windpayment1 = (amount / 100 *9) / 4;
      windpayment2 = ((parseInt(amount) / 100 *9) * 5) + parseInt(amount);
      techpayment1 = (amount / 100 *7.6) / 4;
      techpayment2 = ((parseInt(amount) / 100 *7.6) * 2) + parseInt(amount);
      
      switch(bond) {
          case 'gold': result1name = 'Bi-annual:'; result2name = 'Lump Sum:'; result1 = goldpayment1; result2 = goldpayment2; term = 2; break;
          case 'prop': result1name = 'Annual:'; result2name = 'Lump Sum:'; result1 = proppayment1; result2 = proppayment2; term = 5; break;
          case 'wind': result1name = 'Quarterly:'; result2name = 'Total Payment:';result1 = windpayment1; result2 = windpayment2; term = 5;  break;
          case 'tech': result1name = 'Quarterly:'; result2name = 'Total Payment:';result1 = techpayment1; result2 = techpayment2; term = 2;  break;
          default: result1name = ''; result2name = ''; result1 = 'Foo'; result2 = 'Bar';
      }
      
      compound(amount,1.0105,term,'ISA',false)
  
      $("p.term span").text(term);
      $("p.result1name").text(result1name);
      $("p.result2name").text(result2name);
      $("p.result1 span").text(parseFloat(result1).toFixed(2));
      $("p.result2 span").text(parseFloat(result2).toFixed(2));
      
      $("p.gold-payment1 span").text(parseFloat(goldpayment1).toFixed(2));
      $("p.gold-payment2 span").text(parseFloat(goldpayment2).toFixed(2));
      $("p.property-payment1 span").text(parseFloat(proppayment1).toFixed(2));
      $("p.property-payment2 span").text(parseFloat(proppayment2).toFixed(2));
      $("p.renewables-payment1 span").text(parseFloat(windpayment1).toFixed(2));
      $("p.renewables-payment2 span").text(parseFloat(windpayment2).toFixed(2));
      $("p.tech-payment1 span").text(parseFloat(techpayment1).toFixed(2));
      $("p.tech-payment2 span").text(parseFloat(techpayment2).toFixed(2));

    });