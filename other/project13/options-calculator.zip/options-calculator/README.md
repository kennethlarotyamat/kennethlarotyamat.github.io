# options calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/dingopunch/pen/XWyRpVx](https://codepen.io/dingopunch/pen/XWyRpVx).

