const button =  document.getElementbyID()
const slider = document.getElementbyID(slider)

slider.append(put)