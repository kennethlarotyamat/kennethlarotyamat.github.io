// This function processes a set of numbers based on a chosen operation (e.g., sum, average, max).
function processNumbers() {
    // Retrieve the string of comma-separated numbers from an input element with the ID 'numbers'.
    const numbersStr = document.getElementById('numbers').value;

    // Retrieve the chosen operation (e.g., 'sum', 'average', 'max') from a dropdown or similar element with the ID 'operation'.
    const operation = document.getElementById('operation').value;

    // Get a reference to the HTML element with ID 'result' to display the result later.
    const resultDiv = document.getElementById('result');

    // Convert the string of comma-separated numbers into an array of actual numbers.
    const numbersArray = numbersStr.split(',').map(num => parseInt(num.trim()));

    let result; // This variable will store the final result based on the operation.
    // Use a switch statement to handle different operations.
    switch(operation) {
        case 'sum': // If the operation is 'sum'
            // Calculate the sum of all numbers in the array.
            result = numbersArray.reduce((acc, num) => acc + num, 0);
            break;
        case 'average': // If the operation is 'average'
            // Calculate the average of all numbers in the array.
            result = numbersArray.reduce((acc, num) => acc + num, 0) / numbersArray.length;
            break;
        case 'max': // If the operation is 'max'
            // Find the maximum number in the array.
            result = Math.max(...numbersArray);
            break;
        default: // If none of the above operations were chosen
            result = "Invalid operation!";
    }

    // Display the result in the 'result' element.
    resultDiv.textContent = `The result is: ${result}`;
}
