	//Calculator script
	var uc, cch, c19, c14, c10, residence, options, residence, price, id, room, cost, building, daysInput, adminCost, parkingCost, acCost, mpParent, mpOptions, mpName, mpDesc, mpCost;

	uc = {
		'fullName': "University Commons",
		'abbr': "uc",
		'options': {
			'p3UC': {
				'description': "Private bedroom in a three-bedroom suite",
				'pricing': {
					'u30': 33,
					'o30': 2250
				}
			}
		}
	};
	cch = {
		'fullName': "Canyon Creek Heights",
		'abbr': "cch",
		'options': {
			's2CCH': {
				'description': "Shared bedroom in a two-bedroom apartment",
				'pricing': {
					'u30': 33,
					'o30': 2250
				}
			},
			'p4CCH': {
				'description': "Private Bedroom in four-bedroom Apartment",
				'pricing': {
					'u30': 38,
					'o30': 2750
				}
			},
			'p2CCH': {
				'description': "Private Bedroom in two-bedroom Apartment",
				'pricing': {
					'u30': 43,
					'o30': 3100
				}
			},
			'p1CCH': {
				'description': "Private one-bedroom Apartment",
				'pricing': {
					'u30': 48,
					'o30': 3500
				}
			}
		}
	};
	c19 = {
		'planName': 'Comet 19',
		'description': '19 Meals per Week',
		'rate': 2038.740000000
	};
	c14 = {
		'planName': 'Comet 14',
		'description': '14 Meals per Week',
		'rate': 1807.8600000
	};
	c10 = {
		'planName': 'Comet 10',
		'description': '10 Meals per Week',
		'rate': 1717.5000000
	};

	//HIDES OPTION SELECT ELEMENT UNTIL A RESIDENCE HALL IS CHOSEN
	$(".calculator select[name=option]").hide();
	//HIDES ITEMIZED RECEIPT UNTIL THE CALCULATE BUTTON HAS BEEN CLICKED
	$('.calculator .itemized').hide();
	//HIDES MEAL PLAN DROPDOWN UNTIL THEY CHOOSE THEY WANT A MEAL PLAN
	$('.calculator select[name=mealPlan]').hide();

  //STORES THE LENGTH IN DAYS INPUT
	daysInput = parseInt($('.calculator input[name=days]').val());

	function numberWithCommas(x) {
		x = Number(x).toFixed(2);
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		parts = parts.join(".");
		return parts;
	}

	function resCheck() {
		//STORES THE VALUE OF THE NAME ATTRIBUTE FROM THE RESIDENCE SELECT ELEMENT
		residence = $(".calculator select[name=residence] option:selected").val();

		//STORES THE ROOM OPTIONS NAME ATTRIBUTE FROM THE OPTIONS SELECT ELEMENT
		options = $(".calculator select[name=option] option");

		//STORES THE ROOM TYPE VALUE SELECTED BY THE USER
		id = $(".calculator select[name=option] option:selected").val();
    
    

		//STORE THE COST OF THE ROOM IN THE COST VARIABLE.
		//ROOM TYPE WILL ALWAYS BE ID AND RESIDENCE WILL NEED TO BE HARD CODED
		function getCost(roomType, residence) {
			// building = Object.values(residence);
			// console.log(building);		
			roomTypeDeets = Object.values(residence.options[roomType]);
      desc = roomTypeDeets[0];
      cost = roomTypeDeets[1];
      costu30 = cost.u30;
      costo30 = cost.o30;
      
      // cost = cost[0];

			//DESC USED IN FORMCALC FUNCTION TO GET DESCRIPTION FOR ITEMIZED RECEIPT
			//desc = cost[0];
			//COST USED IN GETCOST AND FORMCALC FUNCTIONS
      //cost = cost[1];
      // if(daysInput >= 31) {
      //   cost = cost[1];
      // } else {
      //   cost = cost[0];
      // }
			
		}

		function formOptions(dataBuilding) {
			//ONCE THE SELECT[NAME=RESIDENCE] FIELD IS POPULATED, THE OPTIONS FIELD POPULATES
			$(".calculator select[name=option]").show();
			//ITERATES THROUGH ALL OF THE ROOM OPTIONS OF BOTH BUILDINGS
			//AND ONLY SHOWS THE MATCHING OPTIONS IN THE OPTIONS FIELD
			$(options).each(function(i) {
				//PULLS THE DATA-BUILDING ATTRIBUTE FROM THE OPTIONS DROPDOWN
				var optionDataBuilding = $(options[i], this).data('building');
				//COMPARES THE DATA-BUILDING ATTRIBUTE WITH THE ABBREVIATION IN THE BUILDING OBJECT
				//TO SEE WHICH OPTIONS TO POPULATE. WE ALSO WANT TO ALWAYS SHOW THE 'UNIT OPTIONS' DROPDOWN
				//REGARDLESS OF WHICH BUILDING'S OPTIONS ARE BEING POPULATED.
				if ((optionDataBuilding == dataBuilding.abbr) || typeof $(options[i], this).data('building') == 'undefined') {
					$(options[i]).show().removeAttr('disabled');
				} else {
					$(options[i]).hide().attr('disabled','disabled');
				}
			});


		}



		//SWITCHES THE ROOM OPTIONS BASED ON THE RESIDENCE VALUE SELECTED BY THE USER
		switch (residence) {
			//THIS IS A HARD CODED LINE THAT CHECKS TO SEE IF THE RESIDENCE VALUE
			//SELECTED BY THE USER IS EQUAL TO A SPECIFIC STRING.
			case (residence = "uc"):
				//SHOWS THE APPROPRIATE OPTIONS FOR THE BUILDING SELECTED
				formOptions(uc);
				//STORES THE COST OF THE UNIT SELECTED
				getCost(id, uc);
				break;

			case (residence = "cch"):
				//SHOWS THE APPROPRIATE OPTIONS FOR THE BUILDING SELECTED
				formOptions(cch);
				//STORES THE COST OF THE UNIT SELECTED
				getCost(id, cch);
				break;

			default:
				//console.log("none are selected");
				$(".calculator select[name=option]").hide();
				$(".calculator select[name=option] option[data-building]").show();
		}

		//MEAL PLAN FUNCTIONS
		//STORES THE OPTIONS OF THE MEAL PLAN SELECT ELEMENT
		mpOptions = $('.calculator select[name=mealPlan] option:selected').val();




		//STORES THE
		function getMPCost(mealPlan) {
			mpName = mealPlan.planName;
			mpDesc = mealPlan.description;
			mpCost = mealPlan.rate;
		}

		switch (mpOptions) {
			case (mpOptions = 'c19'):
				getMPCost(c19);
				break;

			case (mpOptions = 'c14'):
				getMPCost(c14);
				break;

			case (mpOptions = 'c10'):
				getMPCost(c10);
				break;

			default:
				//console.log('default');
				break;
		}
	}

	//

	function showHideMealPlan() {
		if ('.calculator input[name=mealPlanCheck]:checked') {
			$('.calculator select[name=mealPlan]').toggle();
		}
	}

	function resetResidence() {
		$('.calculator select[name=option]').find('option[selected="selected"]').each(function() {
			//$('this').prop('selected', true);
			$('.calculator select[name=option]').reset();
		});
	}


	//THIS FUNCTION CALCULATES ALL OF THE VARIABLES INTO A TOTAL COST.
	function formCalc() {
		//SHOWS THE RECIEPT DIV
		$('.calculator .itemized').show();
		//STORES THE LENGTH IN DAYS INPUT
		daysInput = parseInt($('.calculator input[name=days]').val());

		//THIS IS A HARDCODED PROCESSING FEE.
		adminCost = 300;
		//THIS IS THE LENGTH IN DAYS MULTIPLIED BY THE COST OF THE UNIT SELECTED
		//PLUS THE ADMIN COST. THIS WILL ALWAYS BE THE BARE MINIMUM ARITHMATIC INVOLVED.
    if(daysInput > 30){
      totalCost = costo30;
      $('.calculator .ppd').hide();
      $('.calculator .pps span').html(costo30);
      $('.calculator .admin').hide();
    } else{
      totalCost = (daysInput * costu30);
      totalCost += adminCost;
      //POPULATES THE COST PER DAY IF LESS THAN 30 DAYS
      $('.calculator .admin span').html(adminCost);
      $('.calculator .pps').hide();
      $('.calculator .ppd').show();
      $('.calculator .ppd span').html(costu30);
    }
		
		//THESE ARE THE ADDITIONAL OPTIONS THAT THEY CAN ADD ON AFTER THE TOTAL COST
		//OF THE ROOM HAS BEEN CALCULATED. THIS REFERS TO THE PARKING AND ACTIVITY CENTER
		//COSTS.
		// $('.calculator .additional input[type=checkbox]').each(function() {
		// 	if ($(this).prop('checked')) {
		// 		thisValue = parseInt($(this).val());
		// 		totalCost = totalCost + thisValue;
		// 	}
		// });

		$('.calculator input.additional').each(function() {
			if ($(this).prop('checked')) {
				thisValue = parseInt($(this).val());
				totalCost = totalCost + thisValue;
			}
		});

		if ($('.calculator input[name=mealPlanCheck]').prop('checked')) {
			totalCost = totalCost + mpCost;
		}


		mpCost = numberWithCommas(mpCost);
	  totalCost = numberWithCommas(totalCost);
    costo30 = numberWithCommas(costo30);
		//mpCost = mpCost.toFixed(2);
		//totalCost = totalCost.toFixed(2);
    

		// ------- CREATING ITEMIZED RECEIPT ------ //

		//THERE HAS TO BE A DRY-ER WAY TO GET THE BUILDING NAME
		switch (residence) {
			case (residence = 'uc'):
				$('.calculator .building').html(uc.fullName);
				break;

			case (residence = 'cch'):
				$('.calculator .building').html(cch.fullName);
				break;
		}
		//POPULATES THE OBJECT'S ROOM DESCRIPTION
		$('.calculator .desc').html(desc);
		
		//POPULATES MEAL PLAN DESCRIPTION
		$('.calculator .mealPlanDesc').html(mpDesc);
		//POPULATES MEAL PLAN COST
		$('.calculator .mealPlanCost span').html(mpCost);
		//POPULATES THE HARDCODED PROCESSING FEE
    
		
		//IF THEY CHOSE THE PARKING OR ACTIVITY CENTER OPTIONS, IT POPULATES
		//THEM HERE. IF YOU TOGGLE THE INPUT CHECKBOX IN THE FORM, THE FINAL
		//TOTAL IS UPDATED; HOWEVER, I CAN'T SEEM TO FIGURE OUT TO GET THE
		//SPANS TO TOGGLE THE SAME WAY
		if ($('.calculator .label-container input[name=ac]').prop('checked')) {
			$('.calculator .ac span').html($('.calculator .label-container input[name=ac]').val());
		} else {
			$('.calculator .ac').hide();
		}
		if ($('.calculator .label-container input[name=parking]').prop('checked')) {
			$('.calculator .parking span').html($('.calculator .label-container input[name=parking]').val());
		} else {
			$('.calculator .parking').hide();
		}
		//POPULATES THE TOTAL COST AT THE END
		$('.calculator .total span').html(totalCost);

		//HOW DO WE MAKE IT SO THAT THE MEAL PLAN AND DESCRIPTION DON'T SHOW UP UNLESS THE MEAL PLAN OPTION IS CLICKED
		if($('.calculator .mealPlanCost span').html() != 'NaN'){
			$('.calculator .mealPlanCost').show();
			$('.calculator .mealPlanDesc').show();
		} else {
			$('.calculator .mealPlanCost').hide();
			$('.calculator .mealPlanDesc').hide();
		}

	}

	//RESET FORM
	function resetForm() {
		$('form')[0].reset();
		$('.calculator select').prop('selectedIndex', 0);
		$('.calculator input[type=checkbox]').removeAttr('checked');
		$('input[type=number]').val('');
		$('.calculator .itemized').hide();
		$('.calculator select[name=option]').hide();
		$('.calculator select[name=mealPlan]').hide();

	}

	//INITIATES THE FORM AND CALCULATE BUTTONS
	$('.calculator input[name=mealPlanCheck]').change(showHideMealPlan);
	$(".calculator select").change(resCheck);
	$('#btnCalc').click(formCalc);
	$('#btnReset').click(resetForm);
	$('.calculator select[name=residence]').change(resetResidence);
