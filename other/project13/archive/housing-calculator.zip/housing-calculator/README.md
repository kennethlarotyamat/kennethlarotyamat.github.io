# Housing Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/ssalhanick/pen/jQpPGJ](https://codepen.io/ssalhanick/pen/jQpPGJ).

