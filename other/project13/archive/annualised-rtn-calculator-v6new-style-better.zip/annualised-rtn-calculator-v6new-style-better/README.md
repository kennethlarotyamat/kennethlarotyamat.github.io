# Annualised Rtn Calculator V6 - new style better

A Pen created on CodePen.io. Original URL: [https://codepen.io/kevnea/pen/eYbzjve](https://codepen.io/kevnea/pen/eYbzjve).

