var sampleExerciseCost = 4060;
var sampleCurrentValue = 29610;
var sampleFuture = 173684.1;
// var sampleHref = <a>

let formatDollar = Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2,
  minimumFractionDigits: 2});

var ctx = document.getElementById("myChart1");
Chart.defaults.global.defaultFontFamily = "'Montserrat','Roboto','Arial','sans-serif'";
Chart.defaults.global.tooltips.backgroundColor = 'rgba(0, 0, 0, 0.5)';
Chart.defaults.scale.gridLines.display = false;
Chart.defaults.global.title.fontSize = 18;
Chart.defaults.global.legend.display = false;

              var myChart = new Chart(ctx, {
                  type: 'bar',
                  data: {
                  // The labels are what shows up on the bottom of the x-axis
                      labels: ["Exercise Cost", "Shares at Current Valuation", "Potential Projected Profit"],

                      datasets: [{
                          label: '% of calls mentioning coronavirus',
                         
                          barPercentage: 1,
                          // This is where you put the
                          data: [sampleExerciseCost,sampleCurrentValue,sampleFuture],
                          backgroundColor: ['rgba(189,221,244,0.8)','rgba(149,200,236,0.8)','rgba(112,178,226,0.8)','rgba(87,160,215,0.8)','rgba(71,143,204,0.8)','rgba(61,130,196,0.8)','rgba(51,116,186,0.8)','rgba(43,102,177,0.8)','rgba(20,71,155,0.8)'],
                          hoverBackgroundColor: ['rgba(189,221,244,1)','rgba(149,200,236,1)','rgba(112,178,226,1)','rgba(87,160,215,1)','rgba(71,143,204,1)','rgba(61,130,196,1)','rgba(51,116,186,1)','rgba(43,102,177,1)','rgba(20,71,155,1)']
                      }]
                  },
                  options: {
                  animation: {
                          duration: 1000,
                          easing: 'easeInQuad'
                      },
                      title: {
                      display: true,
                        text: 'Real-Time Stock Options Calculator'
                      },
                  scales: {
                        yAxes: [{
                            ticks: {
                            stepSize: 25000,
                                             // Include a dollar sign in the ticks
                callback: function(value, index, values) {
                  return '$' + value.toLocaleString();
                }
        
                            }
                        }]
                     },
                     tooltips: {
                        enabled: true,
                        mode: 'single',
                        callbacks: {
                            label: function(tooltipItems, data) {
                                return formatDollar.format(tooltipItems.yLabel);
                              // return tooltipItems.index
                            },
                          
                          afterLabel: function (tooltipItems, data){
                            if (tooltipItems.index == 1){

                          return '\nThis is a hypothetical value displaying\nwhat your fully vested shares would be\nworth if you were able to exercise them\nright now.';
                            }
                            else if (tooltipItems.index == 2){
                              return '\nCalculated using the following variables and assumptions: \n  • Projected ending CARR for the quarter in which you decide to exercise \n  • Revenue multiplier of 20x (based on our current growth projections and current market trends)\n  •  Dilution of 15.6%'
                            }
                            else {
                              return "";
                            }
                            // return data;
                        }
                          
                      
                        }
                    }
               
                  }
              });


