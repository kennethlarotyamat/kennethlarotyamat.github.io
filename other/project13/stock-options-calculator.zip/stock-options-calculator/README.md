# Stock Options Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/gobalto/pen/GREyWBx](https://codepen.io/gobalto/pen/GREyWBx).

