# Working Annualised Rtn Calculator v.5

A Pen created on CodePen.io. Original URL: [https://codepen.io/kevnea/pen/NWerwRN](https://codepen.io/kevnea/pen/NWerwRN).

