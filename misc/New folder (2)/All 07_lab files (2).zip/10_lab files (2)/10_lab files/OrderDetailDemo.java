package edu.unlv.mis768.labwork10;

import javax.swing.JOptionPane;

public class OrderDetailDemo {

	public static void main(String[] args) {
		String productName = JOptionPane.showInputDialog("Please enter the product name: ");
		String productType = JOptionPane.showInputDialog("Please enter the product type: ");
		double price = Double.parseDouble((JOptionPane.showInputDialog("Pleae enter the product price: ")));
		
		Product item = ;
		
		int quan = Integer.parseInt(JOptionPane.showInputDialog("Pleae enter the quantity: "));
		
		OrderDetail line = ;
		
		JOptionPane.showConfirmDialog(   );
		JOptionPane.showConfirmDialog(  );
		
	}

}
