package edu.unlv.mis768.labwork10;

public enum CarType {
	POSCHE,
	FERRARI,
	JARGUAR
}
