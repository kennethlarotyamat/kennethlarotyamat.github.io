package edu.unlv.mis768.labwork9;

public class NameTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FullName myName = new FullName();
		
		System.out.println(myName.getLength());

	}

}
