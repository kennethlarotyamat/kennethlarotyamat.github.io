package edu.unlv.mis768.labwork15;

	import javafx.fxml.FXML;
	import javafx.scene.control.Button;
	import javafx.scene.control.ComboBox;
	import javafx.scene.control.TextArea;

	public class ShowSelectionController {

	    @FXML
	    private Button clearButton;

	    @FXML
	    private ComboBox<?> selectionComboBox;

	    @FXML
	    private TextArea contentTextArea;
	    
		/**
	     * The method will be called when FXML file is loaded
	     */
	    public void initialize() {
	    	// this items are for configuring the combobox
	    
	    }
	    
		/**
	     * Action Listener for the button
	     */
	    public void buttonListener() {
	    	// clear the text in the Text Area

	    }

		/**
	     * Action Listener for the combobox
	     */
	    public void comboboxListener() {
	    	// retrieve current content of the Text Area

	    	
	    	// add the value in the combo box

	    	
	    	// set it back to the Text Area

	    }
	}

