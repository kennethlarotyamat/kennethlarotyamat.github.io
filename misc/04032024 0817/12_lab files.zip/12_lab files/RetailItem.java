package edu.unlv.mis768.labwork12;

/**
   RetailItem interface
*/

public interface RetailItem {
   public double getRetailPrice();
}
